# POO-P2-G06
Repositorio para el proyecto de POO.
